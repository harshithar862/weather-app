const apiKey = 'YOUR_API_KEY'; // Replace with your OpenWeatherMap API key

async function getWeather() {
  const city = document.getElementById('city').value;
  const resultDiv = document.getElementById('weather-result');

  if (!city) {
    resultDiv.innerHTML = '<p>Please enter a city name.</p>';
    return;
  }

  try {
    const res = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`
    );
    const data = await res.json();

    if (data.cod === 200) {
      resultDiv.innerHTML = \`
        <h2>\${data.name}, \${data.sys.country}</h2>
        <p><strong>Temperature:</strong> \${data.main.temp} °C</p>
        <p><strong>Condition:</strong> \${data.weather[0].description}</p>
        <p><strong>Humidity:</strong> \${data.main.humidity}%</p>
        <img src="https://openweathermap.org/img/wn/\${data.weather[0].icon}@2x.png" alt="icon">
      \`;
    } else {
      resultDiv.innerHTML = \`<p>\${data.message}</p>\`;
    }
  } catch (error) {
    resultDiv.innerHTML = `<p>Error fetching weather data.</p>`;
  }
}